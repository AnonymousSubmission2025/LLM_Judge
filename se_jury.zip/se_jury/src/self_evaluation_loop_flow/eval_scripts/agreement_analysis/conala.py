import json, pickle
import json, re
from tqdm import tqdm
from itertools import combinations
from sklearn.metrics import cohen_kappa_score
def cohen_kappa_with_tolerance(rater1, rater2, tolerance=1):
  if len(rater1) != len(rater2):
    raise ValueError("Input lists must have the same length")

  adjusted_rater2 = []
  for i in range(len(rater1)):
    if abs(rater1[i] - rater2[i]) <= tolerance:
      adjusted_rater2.append(rater1[i])
    else:
      adjusted_rater2.append(rater2[i])

  return cohen_kappa_score(rater1, adjusted_rater2)


preds, refs, inputs, grades = [],[],[],[]
with open(
  "../../data/conala/conala_grade.json") as f:
  data_for_eval = json.load(f)
  conala_models_list = ['baseline', 'tranx-annot', 'best-tranx', 'best-tranx-rerank', 'codex']
for data in tqdm(data_for_eval):
  PROBLEM = data['intent']
  GT = data['snippet'][0]
  ks = conala_models_list
  for key_s in ks:
    CODE = data[key_s]
    GRADE = data['grade-'+key_s]
    inputs.append(PROBLEM)
    preds.append(CODE)
    refs.append(GT)
    grades.append(GRADE)
fixed_labels = grades
fixed_labels = [l+1 for l in fixed_labels]

annotator_grades = []
with open(
  '../../data/conala/conala-human-grades.json') as f:
  data_example = json.load(f)
  conala_models_list = ['baseline', 'tranx-annot', 'best-tranx', 'best-tranx-rerank', 'codex']
for data in tqdm(data_example ):
  ks = conala_models_list
  for key_s in ks:
    GRADE = data['grade-' + key_s]
    annotator_grades.append(GRADE)


conala_data_ids = list(range(len(inputs)))

annotator_to_labels = {}

for i in range(len(conala_data_ids)):
    g = annotator_grades[i]
    for key_s in g:
      if key_s not in annotator_to_labels:
        annotator_to_labels[key_s] = []
      annotator_to_labels[key_s].append(  (i, g[key_s])  )
print()


if True:

  with open(
    "../../results//agent-score-direct_assess-conala.pkl",
    "rb") as f:
    scores = pickle.load(f)
    conala_models_list = ['baseline', 'tranx-annot', 'best-tranx', 'best-tranx-rerank', 'codex']
    all_agents_scores = []
    for score in scores:
      for key_s in conala_models_list:
        all_agents_scores.append(score['agent-' + key_s])

  with open(
    "../../results/agent-score-direct_compare-conala.pkl",
    "rb") as f:
    scores = pickle.load(f)
    conala_models_list = ['baseline', 'tranx-annot', 'best-tranx', 'best-tranx-rerank', 'codex']
    all_agents_scores2 = []
    for score in scores:
      for key_s in conala_models_list:
        all_agents_scores2.append(score['agent-' + key_s])

  with open(
    "../../results/agent-score-test_gene_reason-conala.pkl",
    "rb") as f:
    scores = pickle.load(f)
    conala_models_list = ['baseline', 'tranx-annot', 'best-tranx', 'best-tranx-rerank', 'codex']
    all_agents_scores3 = []
    for score in scores:
      for key_s in conala_models_list:
        all_agents_scores3.append(score['agent-' + key_s])

  with open(
    "../../results/agent-score-direct_assess_then_validate-conala.pkl",
    "rb") as f:
    scores = pickle.load(f)
    conala_models_list = ['baseline', 'tranx-annot', 'best-tranx', 'best-tranx-rerank', 'codex']
    all_agents_scores4 = []
    for score in scores:
      for key_s in conala_models_list:
        all_agents_scores4.append(score['agent-' + key_s])

  with open(
    "../../results/agent-score-analyze_gt_then_validate-conala.pkl",
    "rb") as f:
    scores = pickle.load(f)
    conala_models_list = ['baseline', 'tranx-annot', 'best-tranx', 'best-tranx-rerank', 'codex']
    all_agents_scores5 = []
    for score in scores:
      for key_s in conala_models_list:
        all_agents_scores5.append(score['agent-' + key_s])

  our_preds, our_preds2, our_preds3, our_preds4, our_preds5 = [], [], [], [], []


  for l in all_agents_scores:
    match = re.search(r'(\d+)\s*\[END\]', l)
    if match:
      l = int(match.group(1))
    else:
      l = l.split('[END]')[0].strip()
    our_preds.append(l)

  for l in all_agents_scores2:
    match = re.search(r'(\d+)\s*\[END\]', l)
    if match:
      l = int(match.group(1))
    else:
      l = l.split('[END]')[0].strip()
    our_preds2.append(l)

  for l in all_agents_scores3:
    match = re.search(r'(\d+)\s*\[END\]', l)
    if match:
      l = int(match.group(1))
    else:
      l = l.split('[END]')[0].strip()
      if not isinstance(l, int):
        l = 0
    our_preds3.append(l)

  for l in all_agents_scores4:
    match = re.search(r'(\d+)\s*\[END\]', l)
    if match:
      l = int(match.group(1))
    else:
      l = l.split('[END]')[0].strip()
      if not isinstance(l, int):
        l = 0
    our_preds4.append(l)

  for l in all_agents_scores5:
    match = re.search(r'(\d+)\s*\[END\]', l)
    if match:
      l = int(match.group(1))
    else:
      l = l.split('[END]')[0].strip()
      if not isinstance(l, int):
        l = 0
    our_preds5.append(l)


  def map_score(old_score):
    return 1 + (old_score / 100) * 4



  our_preds = [map_score(l) for l in our_preds]
  our_preds2 = [map_score(l) for l in our_preds2]
  our_preds3 = [map_score(l) for l in our_preds3]
  our_preds4 = [map_score(l) for l in our_preds4]
  our_preds5 = [map_score(l) for l in our_preds5]


  DEBUG = 0
  import random
  NUM_EXAMPLES = 20
  random.seed(12345)
  indices = random.sample(range(len(our_preds)), NUM_EXAMPLES)
  valid_indices = indices.copy()



  our_preds_mapped, our_preds_mapped2, our_preds_mapped3, our_preds_mapped4, our_preds_mapped5, our_preds_mapped_merged = [], [], [], [], [], []
  for l in our_preds:
    our_preds_mapped.append(round(l))
  for l in our_preds2:
    our_preds_mapped2.append(round(l))
  for l in our_preds3:
    our_preds_mapped3.append(round(l))
  for l in our_preds4:
    our_preds_mapped4.append(round(l))
  for l in our_preds5:
    our_preds_mapped5.append(round(l))

  list_data = {
    'S1': our_preds,
    'S2': our_preds4,
    'S3': our_preds2,
    'S4': our_preds5,
    'S5': our_preds3,
  }
  import numpy as np
  combination_names = ['S1', 'S2', 'S4']
  selected_lists = [list_data[name] for name in combination_names]
  avg_list_ = np.mean(selected_lists, axis=0)
  avg_list_ = avg_list_.tolist()
  avg_list = [round(ll) for ll in avg_list_]

  our_tool_preds = avg_list



annotators_list = ['grader1', 'grader2', 'grader3','grader4', 'grader5', 'grader6', 'grader7', 'grader8', 'grader9', 'grader10', 'grader11', 'grader12', 'grader13', 'grader14', 'grader15']
all_ids, all_labels = [],[]
for annotator in annotators_list:
  res = annotator_to_labels[annotator]
  sorted_res = sorted(res, key=lambda x: x[0])
  sorted_ids = [l[0] for l in sorted_res]
  all_ids.append(sorted_ids)
  all_labels.append([l[1] for l in sorted_res])

tool_preds_agreement = our_tool_preds
tool_preds_agreement_ids = list(range(len(tool_preds_agreement)))




def compute_average_kappa(annotations, annotation_ids, tolerance=1):


  def get_intersection_with_indices(list1, list2):
    set2 = set(list2)
    intersection = []

    for i, item in enumerate(list1):
      if item in set2:
        j = list2.index(item)
        intersection.append((item, i, j))
    return intersection

  annotator_pairs = list(combinations(range(len(annotations)), 2))
  kappa_scores = []
  kappa_t_scores = []
  for i, j in annotator_pairs:
    annotation_ids_1 = annotation_ids[i]
    annotation_ids_2 = annotation_ids[j]
    annotations_1 = annotations[i]
    annotations_2 = annotations[j]

    common_data_points =  get_intersection_with_indices(annotation_ids_1, annotation_ids_2)
    intersected_annotation1,intersected_annotation2 = [],[]
    for _, index_in_i, index_in_j in common_data_points:
      intersected_annotation1.append(annotations_1[index_in_i])
      intersected_annotation2.append(annotations_2[index_in_j])

    if len(intersected_annotation1) <= 1:
      continue

    kappa = cohen_kappa_score(intersected_annotation1, intersected_annotation2)
    kappa_tolerance = cohen_kappa_with_tolerance(intersected_annotation1, intersected_annotation2, tolerance)

    # print(i, j, len(intersected_annotation1), len(intersected_annotation2))
    # print(kappa, kappa_tolerance)
    kappa_scores.append(kappa)
    kappa_t_scores.append(kappa_tolerance)

  # print('kappa:', [round(ll, 2) for ll in kappa_scores])
  # print('MIN kappa:', min(kappa_scores))
  # print('MAX kappa:', max(kappa_scores))
  # print('kappa with tolerance:', [round(ll, 2) for ll in kappa_t_scores])
  # print('MIN kappa tolerance:', min(kappa_t_scores))
  # print('MAX kappa tolerance:', max(kappa_t_scores))
  return sum(kappa_scores) / len(kappa_scores), sum(kappa_t_scores) / len(kappa_t_scores), kappa_scores, kappa_t_scores

def compute_tool_human_kappa(human_annotations, human_annotation_ids, tool_annotation, tool_annotation_ids, tolerance=1):

  def get_intersection_with_indices(list1, list2):
    set2 = set(list2)
    intersection = []

    for i, item in enumerate(list1):
      if item in set2:
        j = list2.index(item)
        intersection.append((item, i, j))
    return intersection

  kappa_scores = []
  kappa_t_scores = []
  for i in range(len(human_annotations)):
    human_data = human_annotations[i]
    human_data_id = human_annotation_ids[i]

    common_data_points = get_intersection_with_indices(human_data_id, tool_annotation_ids)
    intersected_annotation1, intersected_annotation2 = [], []
    for _, index_in_i, index_in_j in common_data_points:
      intersected_annotation1.append(human_data[index_in_i])
      intersected_annotation2.append(tool_annotation[index_in_j])
    if len(intersected_annotation1) <= 1:
      continue

    kappa = cohen_kappa_score(intersected_annotation1, intersected_annotation2)
    kappa_tolerance = cohen_kappa_with_tolerance(intersected_annotation1, intersected_annotation2, tolerance)
    # print(i, len(intersected_annotation1), len(intersected_annotation2))
    # print(kappa, kappa_tolerance)
    kappa_scores.append(kappa)
    kappa_t_scores.append(kappa_tolerance)


  # print('kappa:', [round(ll, 2) for ll in kappa_scores])
  # print('kappa with tolerance:', [round(ll, 2) for ll in kappa_t_scores])
  return sum(kappa_scores) / len(kappa_scores), sum(kappa_t_scores) / len(kappa_t_scores), kappa_scores, kappa_t_scores



human_annotations = all_labels
human_annotations_ids = all_ids
tool_annotation = [ l-1 for l in tool_preds_agreement]
tool_annotation_ids = tool_preds_agreement_ids


RemoveSampleIndex = valid_indices
for i_index in sorted(RemoveSampleIndex, reverse=True):
  _ = tool_annotation.pop(i_index)
  _ = tool_annotation_ids.pop(i_index)



human_kappa, human_kappa_t, human_individual_kappa, _ = compute_average_kappa(human_annotations, human_annotations_ids)
print("Average Human-Human Cohen's Kappa:", human_kappa)
print("Average Human-Human Cohen's Kappa with Tolerance:", human_kappa_t)

tool_human_kappa, tool_human_kappa_t, tool_human_individual_kappa, _= compute_tool_human_kappa(human_annotations, human_annotations_ids, tool_annotation, tool_annotation_ids)
print("Average Tool-Human Cohen's Kappa:", tool_human_kappa)
print("Average Tool-Human Cohen's Kappa with Tolerance:", tool_human_kappa_t)

print("Difference (Human-Human vs. Tool-Human):", human_kappa - tool_human_kappa)




