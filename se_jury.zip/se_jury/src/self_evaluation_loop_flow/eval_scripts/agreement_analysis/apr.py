import pandas as pd
import json, pickle, re
from itertools import combinations
from sklearn.metrics import cohen_kappa_score
import numpy as np



label_data = pd.read_csv('../../data/apr/bach_label.csv')
annotator_ids = label_data['Annotator'].to_list()
patch_ids = label_data['Patch'].to_list()
answers = label_data['Answer'].to_list()

annotator_to_labels = {}
patch_id_to_labels = {}
for i in range(len(patch_ids)):
    annotator_id = annotator_ids[i]
    patch_id = patch_ids [i]
    answer = answers[i]
    if patch_id not in patch_id_to_labels:
      patch_id_to_labels[patch_id] = []
    patch_id_to_labels[patch_id].append( (annotator_id, answer)  )
    if annotator_id not in annotator_to_labels:
      annotator_to_labels[annotator_id] = []
    annotator_to_labels[annotator_id].append( (patch_id, answer) )
print()






with open(
  '../../data/apr/bach_data.pkl',
  'rb') as f:
  all_patch_id, all_project_name, all_bug_id, all_failed_tests, all_failed_tests_name_list, all_failed_tests_content_list, all_tests, all_human_patch, all_tool_patch_author_label, all_tool_patch = pickle.load(f)
  all_author_labels = all_tool_patch_author_label

for l in all_patch_id:
  if int(l) not in patch_id_to_labels:
    print(l)

fixed_labels = []
for i in range(len(all_patch_id)):
  patch_id = int(all_patch_id[i])
  mutil_annotator_results = patch_id_to_labels[patch_id]
  tool_author_label  = all_tool_patch_author_label[i].strip()

  maps = {'Y': 1, 'N': 0, '0': 0}
  votes = [maps[l[1]] for l in mutil_annotator_results]


  if votes.count(1) >= (len(votes)*0.5):
    fixed_labels.append(1)
  else:
    fixed_labels.append(0)






with open(
  "../../results/agent-score-direct_assess-apr.pkl",
  "rb") as f:
  all_agents_scores = pickle.load(f)

with open(
 "../../results/agent-score-direct_compare-apr.pkl",
  "rb") as f:
  all_agents_scores2 = pickle.load(f)

with open(
  "../../results//agent-score-test_gene_reason-apr.pkl",
  "rb") as f:
  all_agents_scores3 = pickle.load(f)

with open(
  "../../results/agent-score-direct_assess_then_validate-apr.pkl",
  "rb") as f:
  all_agents_scores4 = pickle.load(f)

with open(
  "../../results/agent-score-analyze_gt_then_validate-apr.pkl",
  "rb") as f:
  all_agents_scores5 = pickle.load(f)


our_preds, our_preds2, our_preds3, our_preds4, our_preds5 = [],[],[],[],[]
for l in all_agents_scores:
  match = re.search(r'(\d+)\s*\[END\]', l)
  if match:
    l = int(match.group(1))
  else:
    l = l.split('[END]')[0].strip()
  our_preds.append(l)

for l in all_agents_scores2:
  match = re.search(r'(\d+)\s*\[END\]', l)
  if match:
    l = int(match.group(1))
  else:
    l = l.split('[END]')[0].strip()
  our_preds2.append(l)

for l in all_agents_scores3:
  match = re.search(r'(\d+)\s*\[END\]', l)
  if match:
    l = int(match.group(1))
  else:
    l = l.split('[END]')[0].strip()
    if not isinstance(l, int):
      l = 0
  our_preds3.append(l)

for l in all_agents_scores4:
  match = re.search(r'(\d+)\s*\[END\]', l)
  if match:
    l = int(match.group(1))
  else:
    l = l.split('[END]')[0].strip()
    if not isinstance(l, int):
      l = 0
  our_preds4.append(l)


for l in all_agents_scores5:
  match = re.search(r'(\d+)\s*\[END\]', l)
  if match:
    l = int(match.group(1))
  else:
    l = l.split('[END]')[0].strip()
    if not isinstance(l, int):
      l = 0
  our_preds5.append(l)


def map_score(old_score):
  return 1 + (old_score / 100) * 4

our_preds = [map_score(l) for l in our_preds]
our_preds2 = [map_score(l) for l in our_preds2]
our_preds3 = [map_score(l) for l in our_preds3]
our_preds4 = [map_score(l) for l in our_preds4]
our_preds5 = [map_score(l) for l in our_preds5]


DEBUG = 0
import random
NUM_EXAMPLES = 20
random.seed(12345)
indices = random.sample(range(len(our_preds)), NUM_EXAMPLES)
valid_indices = indices.copy()


list_data = {
  'S1': our_preds,
  'S2': our_preds4,
  'S3': our_preds2,
  'S4': our_preds5,
  'S5': our_preds3,
}
combination_names = ['S1', 'S4']
selected_lists = [list_data[name] for name in combination_names]
avg_list_ = np.mean(selected_lists, axis=0)
avg_list_ = avg_list_.tolist()
avg_list = []
for ll in avg_list_:
  if ll > 3:
    avg_list.append(1)
  else:
    avg_list.append(0)

our_tool_preds = avg_list
our_patch_ids = all_patch_id
RemoveSampleIndex = indices
RemovePatchID = [our_patch_ids[l] for l in RemoveSampleIndex]

our_patch_res = {}
for i in range(len(our_patch_ids)):
  id_ = our_patch_ids [i]
  our_patch_res[id_] = our_tool_preds[i]


maps = {'Y': 1, 'N': 0, '0': 0}
G1_annotators = ['G1-P1', 'G1-P2', 'G1-P3', 'G1-P4']
G2_annotators = ['G2-P1', 'G2-P2', 'G2-P3', 'G2-P4', 'G2-P5']
G3_annotators = ['G3-P1', 'G3-P2', 'G3-P3', 'G3-P4', 'G3-P5', 'G3-P6', 'G3-P7', 'G3-P8']
G4_annotators = ['G4-P1', 'G4-P2', 'G4-P3', 'G4-P4', 'G4-P5', 'G4-P6', 'G4-P7']
G5_annotators = ['G5-P1', 'G5-P2', 'G5-P3', 'G5-P4', 'G5-P5', 'G5-P6']
G6_annotators = ['G6-P1', 'G6-P2', 'G6-P3', 'G6-P4', 'G6-P5', 'G6-P6']
G7_annotators = ['G7-P1', 'G7-P2', 'G7-P3', 'G7-P4', 'G7-P5']

agreements_among_human, agreements_tool_human = [],[]
for G_I_annotators in [G1_annotators, G2_annotators, G3_annotators, G4_annotators, G5_annotators, G6_annotators, G7_annotators]:

  ids, labels = [],[]
  for annotator in G_I_annotators:
    res = annotator_to_labels[annotator]
    sorted_res = sorted(res, key=lambda x: x[0])
    sorted_patch_ids, sorted_labels =[],[]
    for i in range(len(sorted_res)):
      if str(sorted_res[i][0]) not in  RemovePatchID:
        sorted_patch_ids.append(sorted_res[i][0])
        sorted_labels.append(maps[sorted_res[i][1]])

    ids.append(sorted_patch_ids)
    labels.append(sorted_labels)

  tool_preds_agreement = []
  for id_ in ids[0]:
    tool_preds_agreement.append(our_patch_res[str(id_)])
    print()


  def compute_average_kappa(annotations):
    annotator_pairs = list(combinations(range(len(annotations)), 2))
    kappa_scores = []

    for i, j in annotator_pairs:
      kappa = cohen_kappa_score(annotations[i], annotations[j])
      kappa_scores.append(kappa)

    # print('kappa:', [round(ll, 2) for ll in kappa_scores])
    # print('MIN kappa:', min(kappa_scores))
    # print('MAX kappa:', max(kappa_scores))
    return sum(kappa_scores) / len(kappa_scores)
  def compute_tool_human_kappa(human_annotations, tool_annotation):
    kappa_scores = [cohen_kappa_score(human, tool_annotation) for human in human_annotations]
    # print('kappa:', [round(ll, 2) for ll in kappa_scores])
    return sum(kappa_scores) / len(kappa_scores)



  human_annotations = labels
  tool_annotation = tool_preds_agreement
  print('\n', len(human_annotations[0]), len(tool_annotation), ids[0][0:30])
  # print(tool_annotation)

  human_kappa = compute_average_kappa(human_annotations)


  tool_human_kappa= compute_tool_human_kappa(human_annotations, tool_annotation)

  agreements_among_human.append(human_kappa)
  agreements_tool_human.append(tool_human_kappa)

print('Human-Human Average:', sum(agreements_among_human)/len(agreements_among_human))
print('Tool-Human Average:', sum(agreements_tool_human)/len(agreements_tool_human))




