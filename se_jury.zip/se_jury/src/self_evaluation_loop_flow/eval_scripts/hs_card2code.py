import pickle
import pandas as pd
import json, pickle, re
from scipy import stats
from numpy import mean
from collections import Counter
import itertools
from numpy import nanmean
import itertools
import numpy as np

def main_hs(DEBUG_CHOICE):
  DEBUG = DEBUG_CHOICE


  preds, refs, inputs, grades = [],[],[],[]
  with open(
    '../data/hs_card2code/test_hs.in') as f:
    all_intents = f.readlines()
  with open(
    "../data/hs_card2code/hs-all-grades.json") as f:
    data_for_eval = json.load(f)
    hs_models_list = ['gcnn', 'nl2code']
  ijk = 0
  for data in data_for_eval:
    PROBLEM = all_intents[ijk]
    GT = data['snippet'][0]
    ijk += 1
    ks = hs_models_list
    for key_s in ks:
      CODE = data[key_s]
      GRADE = data['grade-'+key_s]
      grades.append(GRADE)
  fixed_labels = grades



  with open(
    "../results/agent-score-direct_assess-hs.pkl",
    "rb") as f:
    scores = pickle.load(f)
    hs_models_list = ['gcnn', 'nl2code']
    all_agents_scores = []
    for score in scores:
      for key_s in hs_models_list:
        all_agents_scores.append(score['agent-'+key_s])


  with open(
    "../results/agent-score-direct_compare-hs.pkl",
    "rb") as f:
    scores = pickle.load(f)
    hs_models_list = ['gcnn', 'nl2code']
    all_agents_scores2 = []
    for score in scores:
      for key_s in hs_models_list:
        all_agents_scores2.append(score['agent-' + key_s])


  with open(
    "../results/agent-score-test_gene_reason-hs.pkl",
    "rb") as f:
    scores = pickle.load(f)
    hs_models_list = ['gcnn', 'nl2code']
    all_agents_scores3 = []
    for score in scores:
      for key_s in hs_models_list:
        all_agents_scores3.append(score['agent-' + key_s])

  with open(
    "../results/agent-score-direct_assess_then_Validate-hs.pkl",
    "rb") as f:
    scores = pickle.load(f)
    hs_models_list = ['gcnn', 'nl2code']
    all_agents_scores4 = []
    for score in scores:
      for key_s in hs_models_list:
        all_agents_scores4.append(score['agent-' + key_s])

  with open(
    "../results/agent-score-analyze_gt_then_validate-hs.pkl",
    "rb") as f:
    scores = pickle.load(f)
    hs_models_list = ['gcnn', 'nl2code']
    all_agents_scores5 = []
    for score in scores:
      for key_s in hs_models_list:
        all_agents_scores5.append(score['agent-' + key_s])




  our_preds, our_preds2, our_preds3, our_preds4, our_preds5 = [],[],[],[],[]


  for l in all_agents_scores:
    match = re.search(r'(\d+)\s*\[END\]', l)
    if match:
      l = int(match.group(1))
    else:
      l = l.split('[END]')[0].strip()
    our_preds.append(l)

  for l in all_agents_scores2:
    match = re.search(r'(\d+)\s*\[END\]', l)
    if match:
      l = int(match.group(1))
    else:
      l = l.split('[END]')[0].strip()
    our_preds2.append(l)

  for l in all_agents_scores3:
    match = re.search(r'(\d+)\s*\[END\]', l)
    if match:
      l = int(match.group(1))
    else:
      l = l.split('[END]')[0].strip()
      if not isinstance(l, int):
        l = 0
    our_preds3.append(l)

  for l in all_agents_scores4:
    match = re.search(r'(\d+)\s*\[END\]', l)
    if match:
      l = int(match.group(1))
    else:
      l = l.split('[END]')[0].strip()
      if not isinstance(l, int):
        l = 0
    our_preds4.append(l)

  for l in all_agents_scores5:
    match = re.search(r'(\d+)\s*\[END\]', l)
    if match:
      l = int(match.group(1))
    else:
      l = l.split('[END]')[0].strip()
      if not isinstance(l, int):
        l = 0
    our_preds5.append(l)


  def map_score(old_score):
    return 1 + (old_score / 100) * 4


  our_preds = [map_score(l) for l in our_preds]
  our_preds2 = [map_score(l) for l in our_preds2]
  our_preds3 = [map_score(l) for l in our_preds3]
  our_preds4 = [map_score(l) for l in our_preds4]
  our_preds5 = [map_score(l) for l in our_preds5]

  NUM_EXAMPLES = 20

  # ================= Debug (START) =================
  import random
  random.seed(12345)
  indices = random.sample(range(len(our_preds)), NUM_EXAMPLES)
  validated_indices = indices.copy()
  print(indices)
  if DEBUG == 1:
    print("***** This Is Debugging Setting !! ******")
    our_preds = [our_preds[i] for i in indices]
    our_preds2 = [our_preds2[i] for i in indices]
    our_preds3 = [our_preds3[i] for i in indices]
    our_preds4 = [our_preds4[i] for i in indices]
    our_preds5 = [our_preds5[i] for i in indices]
    fixed_labels = [fixed_labels[i] for i in indices]
  elif DEBUG == 0:
    print("***** This Is TEST Setting !! ******")
    our_preds= [our_preds[i] for i in range(len(our_preds)) if i not in indices]
    our_preds2 = [our_preds2[i] for i in range(len(our_preds2)) if i not in indices]
    our_preds3 = [our_preds3[i] for i in range(len(our_preds3)) if i not in indices]
    our_preds4 = [our_preds4[i] for i in range(len(our_preds4)) if i not in indices]
    our_preds5 = [our_preds5[i] for i in range(len(our_preds5)) if i not in indices]
    fixed_labels = [fixed_labels[i] for i in range(len(fixed_labels)) if i not in indices]
  else:
    pass
  print(len(fixed_labels), len(our_preds), len(our_preds2), len(our_preds3), len(our_preds4), len(our_preds5))

  # ================= Debug (END) =================

  our_preds_mapped, our_preds_mapped2, our_preds_mapped3, our_preds_mapped4, our_preds_mapped5, our_preds_mapped_merged = [],[],[],[],[],[]

  for l in our_preds:
      our_preds_mapped.append(round(l))
  for l in our_preds2:
    our_preds_mapped2.append(round(l))
  for l in our_preds3:
    our_preds_mapped3.append(round(l))
  for l in our_preds4:
    our_preds_mapped4.append(round(l))
  for l in our_preds5:
    our_preds_mapped5.append(round(l))




  if DEBUG == 1:

    list_data = {
      'S1': our_preds_mapped,
      'S2': our_preds_mapped4,
      'S3': our_preds_mapped2,
      'S4': our_preds_mapped5,
      'S5': our_preds_mapped3,
    }

    lists = list(list_data.values())
    names = list(list_data.keys())

    combinations_data = []


    for r in range(2, len(lists) + 1):
      for indices in itertools.combinations(range(len(lists)), r):
        combo_lists = [lists[i] for i in indices]
        combo_names = [names[i] for i in indices]


        avg_list = np.mean(combo_lists, axis=0)
        avg_list = avg_list.tolist()
        avg_list = [round(ll) for ll in avg_list]


        def compute(refs, preds):
          return stats.kendalltau(refs, preds).statistic, \
            stats.pearsonr(refs, preds).statistic, \
            stats.spearmanr(refs, preds).statistic


        kendalls, pearsons, spearmans = [], [], []
        kendall, pearson, spearman = compute(fixed_labels, avg_list)
        avg_cor = round((kendall + pearson + spearman) / 3, 3)



        combinations_data.append({
            'combination_names': combo_names,
            "combination": combo_lists,
            "merged": avg_list,
            "kendall": kendall,
            "pearson": pearson,
            "spearman": spearman,
            "avg_cor": avg_cor,
        })



    max_cor_combo = max(combinations_data, key=lambda x: x["avg_cor"])
    print('combination_names:', max_cor_combo['combination_names'])
    print("kendall:", max_cor_combo["kendall"])
    print("pearson:", max_cor_combo["pearson"])
    print("spearman:", max_cor_combo["spearman"])
    print("avg_cor:", max_cor_combo["avg_cor"])


    with open('../results/hs_selected.txt', 'w') as f:
        f.write('\n'.join(max_cor_combo['combination_names']))
    return {}


  else:
    with open(
      '../results/hs_selected.txt',
      'r') as f:
      combination_names = f.readlines()
    combination_names = [ll.strip() for ll in combination_names]

    list_data = {
      'S1': our_preds_mapped,
      'S2': our_preds_mapped4,
      'S3': our_preds_mapped2,
      'S4': our_preds_mapped5,
      'S5': our_preds_mapped3,
    }

    selected_lists = [list_data[name] for name in combination_names]
    avg_list = np.mean(selected_lists, axis=0)
    avg_list = avg_list.tolist()
    avg_list = [round(ll) for ll in avg_list]

    # Correlation
    def compute(refs, preds):
      return stats.kendalltau(refs, preds).statistic, \
        stats.pearsonr(refs, preds).statistic, \
        stats.spearmanr(refs, preds).statistic

    kendall, pearson, spearman = compute(fixed_labels, avg_list)
    avg_cor = round((kendall + pearson + spearman) / 3, 3)





    print({'combination_names': combination_names, "kendall": round(kendall, 2), "pearson": round(pearson, 2),
           "spearman": round(spearman, 2), "avg_cor": round(avg_cor, 2)})

## find the best team with 20 samples
main_hs(1)

## apply the best team with all rest data samples
main_hs(0)

