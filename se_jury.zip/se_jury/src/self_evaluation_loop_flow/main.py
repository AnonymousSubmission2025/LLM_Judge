from typing import Optional
import json, pickle
from tqdm import tqdm
from crewai.flow.flow import Flow, listen, router, start
from pydantic import BaseModel

from self_evaluation_loop_flow.crews.direct_assess_crew.direct_assess_crew import (
    DirectAssessCrew,
)

from self_evaluation_loop_flow.crews.direct_assess_recheck_crew.direct_assess_recheck_crew import (
    DirectAssessRecheckCrew,
)
from self_evaluation_loop_flow.crews.direct_compare_crew.direct_compare_crew import (
    DirectCompareCrew,
)
from self_evaluation_loop_flow.crews.test_gene_crew.test_gene_crew import (
    TestGeneAndReasonAssessCrew,
)
from self_evaluation_loop_flow.crews.analyze_gt_then_validate_crew.analyze_gt_then_validate_crew import (
    AnalyzeGTAndValidateCrew,
)
import yaml

class JudgeFlowState(BaseModel):
    assess: str = ""
    feedback: Optional[str] = None
    valid: bool = False
    retry_count: int = 0

class JudgeFlow_DirectAssess(Flow[JudgeFlowState]):

    def __init__(self, task, agent_method):
      self.exp_task = task
      self.agent_method = agent_method
      super().__init__()

    @start("here")
    def generate_direct_assess(self):


      if self.exp_task == 'conala':
        """ ------------- CoNaLa -------------- """
        self.state.assess = {}
        with open(
          "./data/conala/conala_grade.json") as f:
          data_for_eval = json.load(f)
          conala_models_list = ['baseline', 'tranx-annot', 'best-tranx', 'best-tranx-rerank', 'codex']
        all_agents_scores = []
        ijk = 0
        for data in tqdm(data_for_eval):
          print('conala data sample ', ijk)
          agents_scores = {}
          PROBLEM = data['intent']
          GT = data['snippet']
          ks = conala_models_list
          for key_s in ks:
            CODE = data[key_s]
            result = (
              DirectAssessCrew()
              .crew()
              .kickoff(inputs={"CODE": CODE, "PROBLEM": PROBLEM, "GT":GT})
            )
            agents_scores['agent-' + key_s] = result.raw
            self.state.assess[str(ijk)+ '-' + key_s] = result.raw

            ijk += 1
          all_agents_scores.append(agents_scores)

        with open(
          "./results/agent-score-" + self.agent_method + "-" + self.exp_task + ".pkl",
          "wb") as f:
          pickle.dump(all_agents_scores, f)


      if self.exp_task == 'hs':

        """ ------------- HeartStone Card2Code -------------- """

        with open(
          './data/hs_card2code/test_hs.in') as f:
          all_intents = f.readlines()
        with open(
          "./data/hs_card2code/hs-all-grades.json") as f:
          data_for_eval = json.load(f)
          hs_models_list = ['gcnn', 'nl2code']

        all_agents_scores = []
        ijk = 0
        for data in tqdm(data_for_eval):
          print('HS data sample ', ijk)
          PROBLEM = all_intents[ijk]
          GT = data['snippet'][0]
          ijk += 1
          agents_scores = {}
          ks = hs_models_list
          for key_s in ks:
            CODE = data[key_s]
            result = (
              DirectAssessCrew()
              .crew()
              .kickoff(inputs={"CODE": CODE, "PROBLEM": PROBLEM, "GT":GT})
            )
            agents_scores['agent-' + key_s] = result.raw

          all_agents_scores.append(agents_scores)
        with open(
          "./results/agent-score-" + self.agent_method + "-" + self.exp_task + ".pkl",
          "wb") as f:
          pickle.dump(all_agents_scores, f)

      if self.exp_task == 'apr':

        """ ------------- APR -------------- """

        with open(
          './data/apr/bach_data.pkl',
          'rb') as f:
          all_patch_id, all_project_name, all_bug_id, all_failed_tests, all_failed_tests_name_list, all_failed_tests_content_list, all_tests, all_human_patch, all_tool_patch_author_label, all_tool_patch = pickle.load(f)
          self.all_patch_id = all_patch_id
          self.all_tool_patch = all_tool_patch
          self.all_human_patch = all_human_patch
          self.all_failed_tests = all_failed_tests
          self.all_failed_tests_content_list = all_failed_tests_content_list
          self.all_tool_patch_author_label = all_tool_patch_author_label

        self.state.assess = []
        for i in tqdm(range(len(self.all_patch_id))):
          print('ITEM ', i)
          patch_id = self.all_patch_id[i]
          if int(patch_id) < 1000:
              PATCH = self.all_tool_patch[i]
              TEST = ''.join(self.all_failed_tests[i])+'Failed Test Cases Content:\n'+'\n'.join(self.all_failed_tests_content_list[i])
              GT = self.all_human_patch[i]
              AuthorLable = self.all_tool_patch_author_label[i]
          else:
              PATCH = self.all_tool_patch[i]
              TEST = 'not available'
              GT = self.all_human_patch[i]
              AuthorLable = 'not available'
          result = (
            DirectAssessCrew()
            .crew()
            .kickoff(inputs={"PATCH": PATCH, "TEST": TEST, "GT": GT}))
          self.state.assess.append(result.raw)


        with open(
          "results/agent-score-" + self.agent_method + "-" + self.exp_task + ".pkl",
          "wb") as f:
          pickle.dump (self.state.assess, f)


      if self.exp_task == 'summarization':
            """ ------------- Code Summarization -------------- """
            import pandas as pd
            df = pd.read_csv(
              './data/summarization/human-annotated-dataset-with-metrics.csv')
            codes = df['codeFunctions'].tolist()
            texts = df['codeComment'].tolist()
            gold_texts = df['originalComment'].tolist()
            grades = df['Content Adequacy'].tolist()
            del df
            all_agents_scores = []
            ijk = 0
            for ijk in tqdm(range(len(codes))):
              print('\nCode Summary data sample ', ijk)
              CODE = codes[ijk]
              TEXT = texts[ijk]
              SCORE = grades[ijk]
              GT = gold_texts[ijk]
              result = (
                DirectAssessCrew()
                .crew()
                .kickoff(inputs={"CODE": CODE, "TEXT": TEXT, "GT":GT})
              )
              all_agents_scores.append(result.raw)


            with open(
              "./results/agent-score-"+self.agent_method+"-"+self.exp_task+".pkl",
              "wb") as f:
              pickle.dump(all_agents_scores, f)


class JudgeFlow_DirectCompare(Flow[JudgeFlowState]):
    def __init__(self, task, agent_method):
      self.exp_task = task
      self.agent_method = agent_method
      super().__init__()


    @start("here")
    def generate_compare_assess(self):



      if self.exp_task == 'conala':

        """ ------------- CoNaLa -------------- """
        self.state.assess = {}
        with open(
          "./data/conala/conala_grade.json") as f:
          data_for_eval = json.load(f)
          conala_models_list = ['baseline', 'tranx-annot', 'best-tranx', 'best-tranx-rerank', 'codex']

        all_agents_scores = []
        ijk = 0
        for data in tqdm(data_for_eval):
          print('conala data sample ', ijk)
          agents_scores = {}
          PROBLEM = data['intent']
          GT = '\n'.join(data['snippet'])
          ks = conala_models_list
          for key_s in ks:
            CODE = data[key_s]
            result = (
              DirectCompareCrew()
              .crew()
              .kickoff(inputs={"CODE": CODE, "PROBLEM": PROBLEM, "GT":GT})
            )
            agents_scores['agent-' + key_s] = result.raw
            self.state.assess[str(ijk)+ '-' + key_s] = result.raw

            ijk += 1
          all_agents_scores.append(agents_scores)

        with open(
          "./results/agent-score-" + self.agent_method + "-" + self.exp_task + ".pkl",
          "wb") as f:
          pickle.dump(all_agents_scores, f)


      if self.exp_task == 'hs':
        """ ------------- HeartStone Card2Code -------------- """
        with open(
          './data/hs_card2code/test_hs.in') as f:
          all_intents = f.readlines()
        with open(
          "./data/hs_card2code/hs-all-grades.json") as f:
          data_for_eval = json.load(f)
          hs_models_list = ['gcnn', 'nl2code']

        all_agents_scores = []
        ijk = 0
        for data in tqdm(data_for_eval):
          print('HS data sample ', ijk)
          PROBLEM = all_intents[ijk]
          GT = data['snippet'][0]
          ijk += 1
          agents_scores = {}
          ks = hs_models_list
          for key_s in ks:
            CODE = data[key_s]
            result = (
              DirectCompareCrew()
              .crew()
              .kickoff(inputs={"CODE": CODE, "PROBLEM": PROBLEM,"GT": GT})
            )
            agents_scores['agent-' + key_s] = result.raw

          all_agents_scores.append(agents_scores)

        with open(
          "./results/agent-score-" + self.agent_method + "-" + self.exp_task + ".pkl",
          "wb") as f:
          pickle.dump(all_agents_scores, f)


      if self.exp_task == 'apr':
        """ ------------- APR -------------- """
        with open(
          './data/apr/bach_data.pkl', 'rb') as f:
          all_patch_id, all_project_name, all_bug_id, all_failed_tests, all_failed_tests_name_list, all_failed_tests_content_list, all_tests, all_human_patch, all_tool_patch_author_label, all_tool_patch = pickle.load(
            f)
          self.all_patch_id = all_patch_id
          self.all_tool_patch = all_tool_patch
          self.all_human_patch = all_human_patch
          self.all_failed_tests = all_failed_tests
          self.all_failed_tests_content_list = all_failed_tests_content_list
          self.all_tool_patch_author_label = all_tool_patch_author_label

        self.state.assess = []
        for i in tqdm(range(len(self.all_patch_id))):
          print('ITEM ', i)
          patch_id = self.all_patch_id[i]
          if int(patch_id) < 1000:
            PATCH = self.all_tool_patch[i]
            TEST = ''.join(self.all_failed_tests[i]) + 'Failed Test Cases Content:\n' + '\n'.join(
              self.all_failed_tests_content_list[i])
            GT = self.all_human_patch[i]
            AuthorLable = self.all_tool_patch_author_label[i]
          else:
            PATCH = self.all_tool_patch[i]
            TEST = 'not available'
            GT = self.all_human_patch[i]
            AuthorLable = 'not available'
          result = (
            DirectCompareCrew()
            .crew()
            .kickoff(inputs={"PATCH": PATCH, "TEST": TEST, "GT": GT}))
          self.state.assess.append(result.raw)

        with open(
          "./results/agent-score-" + self.agent_method + "-" + self.exp_task + ".pkl",
          "wb") as f:
          pickle.dump(self.state.assess, f)



      if self.exp_task == 'summarization':
            """ ------------- Code Summarization -------------- """
            import pandas as pd
            df = pd.read_csv(
              './data/summarization/human-annotated-dataset-with-metrics.csv')
            codes = df['codeFunctions'].tolist()
            texts = df['codeComment'].tolist()
            gold_texts = df['originalComment'].tolist()
            grades = df['Content Adequacy'].tolist()
            del df
            all_agents_scores = []
            ijk = 0
            for ijk in tqdm(range(len(codes))):
              print('\nCode Summary data sample ', ijk)
              CODE = codes[ijk]
              TEXT = texts[ijk]
              SCORE = grades[ijk]
              GT = gold_texts[ijk]
              result = (
                DirectCompareCrew()
                .crew()
                .kickoff(inputs={"CODE": CODE, "TEXT": TEXT, "GT":GT})
              )
              all_agents_scores.append(result.raw)


            with open(
              "./results/agent-score-"+self.agent_method+"-"+self.exp_task+".pkl",
              "wb") as f:
              pickle.dump(all_agents_scores, f)


class JudgeFlow_TestGeneReason(Flow[JudgeFlowState]):
    def __init__(self, task, agent_method):
      self.exp_task = task
      self.agent_method = agent_method
      super().__init__()

    @start("here")
    def generate_test_cases_and_reasoning_assess(self):


      if self.exp_task == 'conala':

        """ ------------- CoNaLa -------------- """

        self.state.assess = {}
        with open(
          "./data/conala/conala_grade.json") as f:
          data_for_eval = json.load(f)
          conala_models_list = ['baseline', 'tranx-annot', 'best-tranx', 'best-tranx-rerank', 'codex']

        all_agents_scores = []
        ijk = 0
        for data in tqdm(data_for_eval):
          print('conala data sample ', ijk)
          agents_scores = {}
          PROBLEM = data['intent']
          GT = '\n'.join(data['snippet'])
          ks = conala_models_list
          for key_s in ks:
            CODE = data[key_s]
            result = (
              TestGeneAndReasonAssessCrew()
              .crew()
              .kickoff(inputs={"CODE": CODE, "PROBLEM": PROBLEM, "GT": GT})
            )
            agents_scores['agent-' + key_s] = result.raw
            self.state.assess[str(ijk) + '-' + key_s] = result.raw

            ijk += 1
          all_agents_scores.append(agents_scores)

        with open(
         "./results/agent-score-" + self.agent_method + "-" + self.exp_task + ".pkl",
          "wb") as f:
          pickle.dump(all_agents_scores, f)

      if self.exp_task == 'hs':

        """ ------------- HeartStone Card2Code -------------- """

        with open(
          './data/hs_card2code/test_hs.in') as f:
          all_intents = f.readlines()
        with open(
          "./data/hs_card2code/hs-all-grades.json") as f:
          data_for_eval = json.load(f)
          hs_models_list = ['gcnn', 'nl2code']

        all_agents_scores = []
        ijk = 0
        for data in tqdm(data_for_eval):
          print('HS data sample ', ijk)
          PROBLEM = all_intents[ijk]
          GT = data['snippet'][0]
          ijk += 1
          agents_scores = {}
          ks = hs_models_list
          for key_s in ks:
            CODE = data[key_s]
            result = (
              TestGeneAndReasonAssessCrew()
              .crew()
              .kickoff(inputs={"CODE": CODE, "PROBLEM": PROBLEM, "GT": GT})
            )
            agents_scores['agent-' + key_s] = result.raw

          all_agents_scores.append(agents_scores)

        with open(
          "./results/agent-score-" + self.agent_method + "-" + self.exp_task + ".pkl",
          "wb") as f:
          pickle.dump(all_agents_scores, f)

      if self.exp_task == 'apr':

        """ ------------- APR -------------- """

        with open(
          './data/apr/bach_data.pkl',
          'rb') as f:
          all_patch_id, all_project_name, all_bug_id, all_failed_tests, all_failed_tests_name_list, all_failed_tests_content_list, all_tests, all_human_patch, all_tool_patch_author_label, all_tool_patch = pickle.load(
            f)
          self.all_patch_id = all_patch_id
          self.all_tool_patch = all_tool_patch
          self.all_human_patch = all_human_patch
          self.all_failed_tests = all_failed_tests
          self.all_failed_tests_content_list = all_failed_tests_content_list
          self.all_tool_patch_author_label = all_tool_patch_author_label

        self.state.assess = []
        for i in tqdm(range(len(self.all_patch_id))):
          print('ITEM ', i)
          patch_id = self.all_patch_id[i]
          if int(patch_id) < 1000:
            PATCH = self.all_tool_patch[i]
            TEST = '\n'.join(self.all_failed_tests_content_list[i])
            GT = self.all_human_patch[i]
            AuthorLable = self.all_tool_patch_author_label[i]
          else:
            PATCH = self.all_tool_patch[i]
            TEST = 'not available'
            GT = self.all_human_patch[i]
            AuthorLable = 'not available'
          result = (
            TestGeneAndReasonAssessCrew()
            .crew()
            .kickoff(inputs={"PATCH": PATCH, "TEST": TEST, "GT": GT}))
          self.state.assess.append(result.raw)

        with open(
          "./results/agent-score-" + self.agent_method + "-" + self.exp_task + ".pkl",
          "wb") as f:
          pickle.dump(self.state.assess, f)

class JudgeFlow_AssessAndValidate(Flow[JudgeFlowState]):

  def __init__(self, task, agent_method):
    self.exp_task = task
    self.agent_method = agent_method
    super().__init__()

  @start("here")
  def generate_direct_assess(self):


    if self.exp_task == 'conala':
      """ ------------- CoNaLa -------------- """
      self.state.assess = {}
      with open(
        "./data/conala/conala_grade.json") as f:
        data_for_eval = json.load(f)
        conala_models_list = ['baseline', 'tranx-annot', 'best-tranx', 'best-tranx-rerank', 'codex']
      all_agents_scores = []
      ijk = 0
      for data in tqdm(data_for_eval):
        print('conala data sample ', ijk)
        agents_scores = {}
        PROBLEM = data['intent']
        GT = data['snippet']
        ks = conala_models_list
        for key_s in ks:
          CODE = data[key_s]
          result = (
            DirectAssessRecheckCrew()
            .crew()
            .kickoff(inputs={"CODE": CODE, "PROBLEM": PROBLEM, "GT": GT})
          )
          agents_scores['agent-' + key_s] = result.raw
          self.state.assess[str(ijk) + '-' + key_s] = result.raw

          ijk += 1
        all_agents_scores.append(agents_scores)

      with open(
        "./results/agent-score-" + self.agent_method + "-" + self.exp_task + ".pkl",
        "wb") as f:
        pickle.dump(all_agents_scores, f)

    if self.exp_task == 'hs':

      """ ------------- HeartStone Card2Code -------------- """

      with open(
        './data/hs_card2code/test_hs.in') as f:
        all_intents = f.readlines()
      with open(
        "./data/hs_card2code/hs-all-grades.json") as f:
        data_for_eval = json.load(f)
        hs_models_list = ['gcnn', 'nl2code']

      all_agents_scores = []
      ijk = 0
      for data in tqdm(data_for_eval):
        print('HS data sample ', ijk)
        PROBLEM = all_intents[ijk]
        GT = data['snippet'][0]
        ijk += 1
        agents_scores = {}
        ks = hs_models_list
        for key_s in ks:
          CODE = data[key_s]
          result = (
            DirectAssessRecheckCrew()
            .crew()
            .kickoff(inputs={"CODE": CODE, "PROBLEM": PROBLEM, "GT": GT})
          )
          agents_scores['agent-' + key_s] = result.raw

        all_agents_scores.append(agents_scores)
      with open(
        "./results/agent-score-" + self.agent_method + "-" + self.exp_task + ".pkl",
        "wb") as f:
        pickle.dump(all_agents_scores, f)

    if self.exp_task == 'apr':

      """ ------------- APR -------------- """

      with open(
        './data/apr/bach_data.pkl',
        'rb') as f:
        all_patch_id, all_project_name, all_bug_id, all_failed_tests, all_failed_tests_name_list, all_failed_tests_content_list, all_tests, all_human_patch, all_tool_patch_author_label, all_tool_patch = pickle.load(
          f)
        self.all_patch_id = all_patch_id
        self.all_tool_patch = all_tool_patch
        self.all_human_patch = all_human_patch
        self.all_failed_tests = all_failed_tests
        self.all_failed_tests_content_list = all_failed_tests_content_list
        self.all_tool_patch_author_label = all_tool_patch_author_label

      self.state.assess = []
      for i in tqdm(range(len(self.all_patch_id))):

        print('ITEM ', i)
        patch_id = self.all_patch_id[i]
        if int(patch_id) < 1000:
          PATCH = self.all_tool_patch[i]
          TEST = ''.join(self.all_failed_tests[i]) + 'Failed Test Cases Content:\n' + '\n'.join(
            self.all_failed_tests_content_list[i])
          GT = self.all_human_patch[i]
          AuthorLable = self.all_tool_patch_author_label[i]
        else:
          PATCH = self.all_tool_patch[i]
          TEST = 'not available'
          GT = self.all_human_patch[i]
          AuthorLable = 'not available'
        result = (
          DirectAssessRecheckCrew()
          .crew()
          .kickoff(inputs={"PATCH": PATCH, "TEST": TEST, "GT": GT}))
        self.state.assess.append(result.raw)


      with open(
        "./results/agent-score-" + self.agent_method + "-" + self.exp_task + ".pkl",
        "wb") as f:
        pickle.dump(self.state.assess, f)

    if self.exp_task == 'summarization':
      """ ------------- Code Summarization -------------- """
      import pandas as pd
      df = pd.read_csv(
        './data/summarization/human-annotated-dataset-with-metrics.csv')
      codes = df['codeFunctions'].tolist()
      texts = df['codeComment'].tolist()
      gold_texts = df['originalComment'].tolist()
      grades = df['Content Adequacy'].tolist()
      del df
      all_agents_scores = []
      ijk = 0
      for ijk in tqdm(range(len(codes))):
        print('\nCode Summary data sample ', ijk)
        CODE = codes[ijk]
        TEXT = texts[ijk]
        SCORE = grades[ijk]
        GT = gold_texts[ijk]
        result = (
          DirectAssessRecheckCrew()
          .crew()
          .kickoff(inputs={"CODE": CODE, "TEXT": TEXT, "GT": GT})
        )
        all_agents_scores.append(result.raw)


      with open(
        "./results/agent-score-" + self.agent_method + "-" + self.exp_task + ".pkl",
        "wb") as f:
        pickle.dump(all_agents_scores, f)

class JudgeFlow_AnalyzeGtValidate(Flow[JudgeFlowState]):

  def __init__(self, task, agent_method):
    self.exp_task = task
    self.agent_method = agent_method
    super().__init__()

  @start("here")
  def generate_direct_assess(self):


    if self.exp_task == 'conala':
      """ ------------- CoNaLa -------------- """
      self.state.assess = {}
      with open(
        "./data/conala/conala_grade.json") as f:
        data_for_eval = json.load(f)
        conala_models_list = ['baseline', 'tranx-annot', 'best-tranx', 'best-tranx-rerank', 'codex']
      all_agents_scores = []
      ijk = 0
      for data in tqdm(data_for_eval):

        print('conala data sample ', ijk)
        agents_scores = {}
        PROBLEM = data['intent']
        GT = data['snippet']
        ks = conala_models_list
        for key_s in ks:
          CODE = data[key_s]
          result = (
            AnalyzeGTAndValidateCrew()
            .crew()
            .kickoff(inputs={"CODE": CODE, "PROBLEM": PROBLEM, "GT": GT})
          )
          agents_scores['agent-' + key_s] = result.raw
          self.state.assess[str(ijk) + '-' + key_s] = result.raw

          ijk += 1
        all_agents_scores.append(agents_scores)

      with open(
        "./results/agent-score-" + self.agent_method + "-" + self.exp_task + ".pkl",
        "wb") as f:
        pickle.dump(all_agents_scores, f)

    if self.exp_task == 'hs':

      """ ------------- HeartStone Card2Code -------------- """

      with open(
        './data/hs_card2code/test_hs.in') as f:
        all_intents = f.readlines()
      with open(
        "./data/hs_card2code/hs-all-grades.json") as f:
        data_for_eval = json.load(f)
        hs_models_list = ['gcnn', 'nl2code']

      all_agents_scores = []
      ijk = 0
      for data in tqdm(data_for_eval):

        print('HS data sample ', ijk)
        PROBLEM = all_intents[ijk]
        GT = data['snippet'][0]
        ijk += 1
        agents_scores = {}
        ks = hs_models_list
        for key_s in ks:
          CODE = data[key_s]
          result = (
            AnalyzeGTAndValidateCrew()
            .crew()
            .kickoff(inputs={"CODE": CODE, "PROBLEM": PROBLEM, "GT": GT})
          )
          agents_scores['agent-' + key_s] = result.raw

        all_agents_scores.append(agents_scores)
      with open(
        "results/agent-score-" + self.agent_method + "-" + self.exp_task + ".pkl",
        "wb") as f:
        pickle.dump(all_agents_scores, f)

    if self.exp_task == 'apr':

      """ ------------- APR -------------- """

      with open(
        './data/apr/bach_data.pkl',
        'rb') as f:
        all_patch_id, all_project_name, all_bug_id, all_failed_tests, all_failed_tests_name_list, all_failed_tests_content_list, all_tests, all_human_patch, all_tool_patch_author_label, all_tool_patch = pickle.load(
          f)
        self.all_patch_id = all_patch_id
        self.all_tool_patch = all_tool_patch
        self.all_human_patch = all_human_patch
        self.all_failed_tests = all_failed_tests
        self.all_failed_tests_content_list = all_failed_tests_content_list
        self.all_tool_patch_author_label = all_tool_patch_author_label

      self.state.assess = []
      for i in tqdm(range(len(self.all_patch_id))):
        print('ITEM ', i)
        patch_id = self.all_patch_id[i]
        if int(patch_id) < 1000:
          PATCH = self.all_tool_patch[i]
          TEST = ''.join(self.all_failed_tests[i]) + 'Failed Test Cases Content:\n' + '\n'.join(
            self.all_failed_tests_content_list[i])
          GT = self.all_human_patch[i]
          AuthorLable = self.all_tool_patch_author_label[i]
        else:
          PATCH = self.all_tool_patch[i]
          TEST = 'not available'
          GT = self.all_human_patch[i]
          AuthorLable = 'not available'
        result = (
          AnalyzeGTAndValidateCrew()
          .crew()
          .kickoff(inputs={"PATCH": PATCH, "TEST": TEST, "GT": GT}))
        self.state.assess.append(result.raw)


      with open(
        "./results/agent-score-" + self.agent_method + "-" + self.exp_task + ".pkl",
        "wb") as f:
        pickle.dump(self.state.assess, f)

    if self.exp_task == 'summarization':
      """ ------------- Code Summarization -------------- """
      import pandas as pd
      df = pd.read_csv(
        './data/summarization/human-annotated-dataset-with-metrics.csv')
      codes = df['codeFunctions'].tolist()
      texts = df['codeComment'].tolist()
      gold_texts = df['originalComment'].tolist()
      grades = df['Content Adequacy'].tolist()
      del df
      all_agents_scores = []
      ijk = 0
      for ijk in tqdm(range(len(codes))):
        print('\nCode Summary data sample ', ijk)
        CODE = codes[ijk]
        TEXT = texts[ijk]
        SCORE = grades[ijk]
        GT = gold_texts[ijk]
        result = (
          AnalyzeGTAndValidateCrew()
          .crew()
          .kickoff(inputs={"CODE": CODE, "TEXT": TEXT, "GT": GT})
        )
        all_agents_scores.append(result.raw)


      with open(
        "./results/agent-score-" + self.agent_method + "-" + self.exp_task + ".pkl",
        "wb") as f:
        pickle.dump(all_agents_scores, f)


def kickoff(config):
    if config['agent_method'] == 'direct_assess':
      judge_flow = JudgeFlow_DirectAssess(config['task'], config['agent_method'])

    elif config['agent_method'] == 'direct_compare':
      judge_flow = JudgeFlow_DirectCompare(config['task'], config['agent_method'])

    elif config['agent_method'] == 'test_gene_reason':
      judge_flow = JudgeFlow_TestGeneReason(config['task'], config['agent_method'])

    elif config['agent_method'] == 'direct_assess_then_Validate':
      judge_flow = JudgeFlow_AssessAndValidate(config['task'], config['agent_method'])

    elif config['agent_method'] == 'analyze_gt_then_validate':
      judge_flow = JudgeFlow_AnalyzeGtValidate(config['task'], config['agent_method'])

    judge_flow.kickoff()


def plot():
    judge_flow = JudgeFlow_DirectAssess()
    judge_flow.plot()


if __name__ == "__main__":


    config_path = './exp.yaml'
    with open(config_path, 'r') as file:
      exp_setup = yaml.safe_load(file)
    print(exp_setup)
    kickoff(exp_setup)
