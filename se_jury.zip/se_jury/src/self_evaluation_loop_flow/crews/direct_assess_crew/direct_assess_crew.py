from crewai import Agent, Crew, Process, Task
from crewai.project import CrewBase, agent, crew, task
from self_evaluation_loop_flow.tools.CharacterCounterTool import CharacterCounterTool
# from crewai import LLM
from crewai.llm import LLM
import yaml

@CrewBase
class DirectAssessCrew:
    import os
    CUR_PATH = os.getcwd()
    config_path = CUR_PATH + '/exp.yaml'
    # print(config_path)

    with open(config_path, 'r') as file:
      exp_setup = yaml.safe_load(file)
    # print(exp_setup)
    agents_config = "config/agents_"+exp_setup["task"]+".yaml"
    tasks_config = "config/tasks_"+exp_setup["task"]+".yaml"
    # print(agents_config, tasks_config)


    @agent
    def direct_assess(self) -> Agent:
        return Agent(
            config=self.agents_config["direct_assess"],
            llm=LLM(model="gpt-4o-mini",temperature=0, max_tokens=10000, seed=42)
        )

    @task
    def write_direct_assess(self) -> Task:
        return Task(
            config=self.tasks_config["write_direct_assess"],
        )

    @crew
    def crew(self) -> Crew:
        return Crew(
            agents=self.agents,
            tasks=self.tasks,
            process=Process.sequential,
            verbose=True,
        )
