from crewai import Agent, Crew, Process, Task
from crewai.project import CrewBase, agent, crew, task
from self_evaluation_loop_flow.tools.CharacterCounterTool import CharacterCounterTool
# from crewai import LLM
from crewai.llm import LLM
import yaml

@CrewBase
class TestGeneAndReasonAssessCrew:
    import os
    CUR_PATH = os.getcwd()
    config_path = CUR_PATH + '/exp.yaml'
    # print(config_path)

    with open(config_path, 'r') as file:
      exp_setup = yaml.safe_load(file)
    # print(exp_setup)
    agents_config = "config/agents_" + exp_setup["task"] + ".yaml"
    tasks_config = "config/tasks_" + exp_setup["task"] + ".yaml"
    # print(agents_config, tasks_config)




    @agent
    def test_generator(self) -> Agent:
        return Agent(
            config=self.agents_config["test_generator"],
            llm=LLM(model="gpt-4o-mini",temperature=0, max_tokens=10000, seed=42)
        )

    @agent
    def test_reasoner(self) -> Agent:
      return Agent(
        config=self.agents_config["test_reasoner"],
        llm=LLM(model="gpt-4o-mini", temperature=0, max_tokens=10000, seed=42)
      )


    @task
    def generate_test_cases(self) -> Task:
        return Task(
            config=self.tasks_config["generate_test_cases"],
        )

    @task
    def perform_test_reasoning(self) -> Task:
      return Task(
        config=self.tasks_config["perform_test_reasoning"],
        context=[self.generate_test_cases()]
      )

    @crew
    def crew(self) -> Crew:
        return Crew(
            agents=self.agents,
            tasks=self.tasks,
            process=Process.sequential,
            verbose=True,
        )
