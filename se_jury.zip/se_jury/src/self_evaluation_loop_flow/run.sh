export OPENAI_API_KEY=<Please Fill in Your OpenAI Key here>
export OPENAI_MODEL_NAME=gpt-4o-mini-2024-07-18
python main.py

