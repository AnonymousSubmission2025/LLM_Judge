import pickle

f = open('./results/agent-score-analyze_gt_then_validate-summarization.pkl', 'rb')
data = pickle.load(f)
print(data)